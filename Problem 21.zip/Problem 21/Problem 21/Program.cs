﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Problem_21
{
    class Program
    {
        [SuppressMessage("ReSharper.DPA", "DPA0003: Excessive memory allocations in LOH",
            MessageId = "type: System.Int32[]")]
        static void Main(string[] args)
        {
            //Stopwatch stopWatch = new Stopwatch();
            //stopWatch.Start();

            //int number = 220;

            FindingDivisors primeDivisors = new FindingDivisors();

            primeDivisors.Divisors(220);


            string str = "1234";
            int index = -1;
            string curr = "";
            //string[] PowerSet = powerSet(str, index, 0,curr);
        }
    }
}
